package com.kh.practice1.run;

import com.kh.practice1.func.VariablePractice1;
import com.kh.practice1.func.VariablePractice2;
import com.kh.practice1.func.VariablePractice3;
import com.kh.practice1.func.VariablePractice4;

public class Run {
	public static void main(String[] args) {
		VariablePractice1 a = new VariablePractice1();
		
		a.practice1();
		
		
		VariablePractice2 b = new VariablePractice2();
		
		b.practice2();
		
		VariablePractice3 c = new VariablePractice3();
		
		c.practice3();
		
		
		VariablePractice4 d = new VariablePractice4();
		d.practice4();

	
	}

}
